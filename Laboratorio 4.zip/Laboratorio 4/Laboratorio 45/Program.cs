﻿using System;
namespace Laboratorio_45;

public class Program
{
    static void Main(string[] args)
    {
        //Declaración de variables

        int edad1;
        int edad2;
        int edad3;
        int edad4;
        int edad5 = 31;

        //Inicializando variables
        edad1 = edad2 = edad3 = edad4 = 32;
        Console.WriteLine("{0},{1},{2},{3},{4}", edad1 , edad2 , edad3 , edad4, edad5 );
    }
}